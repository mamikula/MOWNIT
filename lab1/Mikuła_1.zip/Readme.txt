Przesyłam cały projekt zbudowany w CLion, powinny być wszystkie pliki,
a program powinien sie uruchamiać "strzałką" 